package com.travix.medusa.busyflights.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsRequest;
import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsResponse;

@RestController
@RequestMapping("/search/")
public class SearchFlightWebAPI {
	
	private final BusyFlightServiceImpl busyFlightService;
	
	@Autowired
	public SearchFlightWebAPI(BusyFlightServiceImpl busyFlightService) {
		this.busyFlightService =busyFlightService; 
		
	}
	
@GetMapping("/flights")
@ResponseBody
public List<BusyFlightsResponse> searchFlight(@RequestBody BusyFlightsRequest busyFlightReq){
	return busyFlightService.searchFlight(busyFlightReq);
	
	
	
	
	
}

}
