package com.travix.medusa.busyflights.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsRequest;

public class ToughJetService  implements SupplierSevice{

	@Autowired
	private  BusyFlightServiceImpl busyFlightService;
	List toughjetFlightList = null;

	@Override
	public List searchFlights(BusyFlightsRequest busyFlightRequest) {
		//Return list of flights from CrazyAirservice
		return toughjetFlightList;
	}


}
