package com.travix.medusa.busyflights.Controller;

import java.util.List;

import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsRequest;

public interface SupplierSevice {
	List searchFlights(BusyFlightsRequest busyFlightRequest);

}
